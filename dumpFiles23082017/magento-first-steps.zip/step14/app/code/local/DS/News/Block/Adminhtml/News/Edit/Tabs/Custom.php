<?php

class DS_News_Block_Adminhtml_News_Edit_Tabs_Custom extends Mage_Adminhtml_Block_Widget
{

    protected function _toHtml()
    {
        return '<h2>Custom Fields</h2>';
    }

}
