<?php

class DS_News_Block_Adminhtml_News extends Mage_Adminhtml_Block_Abstract
{

    public function _toHtml()
    {
        return '<h1>News Module: Admin section</h1>';
    }

}