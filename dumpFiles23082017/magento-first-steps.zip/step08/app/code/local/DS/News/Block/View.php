<?php

class DS_News_Block_View extends Mage_Core_Block_Template
{

}