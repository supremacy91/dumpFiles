<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Xnotif
 */


class Amasty_Xnotif_Block_Product_View_Type_Configurable_Pure extends Amasty_Conf_Block_Catalog_Product_View_Type_Configurable{}
