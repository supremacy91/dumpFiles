<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Xnotif
 */


class Amasty_Xnotif_Block_Product_View_Type_Configurable_Pure extends Amasty_Stockstatus_Block_Rewrite_Product_View_Type_Configurable{}
