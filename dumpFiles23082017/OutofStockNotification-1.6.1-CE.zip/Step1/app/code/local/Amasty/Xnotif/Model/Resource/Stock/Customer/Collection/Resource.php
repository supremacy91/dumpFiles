<?php
/**
 * @author Amasty Team
 * @copyright Copyright (c) 2017 Amasty (https://www.amasty.com)
 * @package Amasty_Xnotif
 */


class Amasty_Xnotif_Model_Resource_Stock_Customer_Collection_Pure extends Mage_ProductAlert_Model_Resource_Stock_Customer_Collection{}
